#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
double acc[10000][2];
double** trc;
int assign_line;
int num_threads;
int num_trc;
int num_done;
int curr[10000];
pthread_mutex_t assign_lock;
pthread_mutex_t transact_lock;
void* work(void* t)
{
	int l;
	while(num_done<num_trc)
	{
		pthread_mutex_lock(&assign_lock);
		if(assign_line>=num_trc)
		{
		      pthread_mutex_unlock(&assign_lock);
		      break;
		}
		l=assign_line;
		assign_line+=1;
		if(trc[l][4]==0)
		{
		      while(curr[(int)trc[l][3]-1001]==1)
		      {
		      	   // WAIT
		      }
		      curr[(int)trc[l][3]-1001]=1;
		}
		else
		{
		      while(curr[(int)trc[l][3]-1001]==1 || curr[(int)trc[l][4]-1001]==1)
		      {
		      	   // WAIT
		      }
		      curr[(int)trc[l][3]-1001]=1;
		      curr[(int)trc[l][4]-1001]=1;
		}
		pthread_mutex_unlock(&assign_lock);
		if(trc[l][1]==1)
		{
		      acc[(int)trc[l][3]-1001][1]+=99*trc[l][2]/100;
		}
		else if(trc[l][1]==2)
		{
		      acc[(int)trc[l][3]-1001][1]-=101*trc[l][2]/100;
 		}
		else if(trc[l][1]==3)
		{
		      acc[(int)trc[l][3]-1001][1]*=107.1/100;
		}
		else
		{
		      acc[(int)trc[l][3]-1001][1]-=101*trc[l][2]/100;
		      acc[(int)trc[l][4]-1001][1]+=99*trc[l][2]/100;
 		}
		if(trc[l][4]==0)
		      curr[(int)trc[l][3]-1001]=0;
		else
		{
		      curr[(int)trc[l][3]-1001]=0;
		      curr[(int)trc[l][4]-1001]=0;
		}
		pthread_mutex_lock(&transact_lock);
		num_done+=1;
		pthread_mutex_unlock(&transact_lock);
	}
}
int main(int argc,char** argv)
{
	FILE* fp;
	int i,j;
	num_trc=atoi(argv[3]);
	num_threads=atoi(argv[4]);
	fp=fopen(argv[1],"r");
	for(i=0;i<10000;i++)
	{
	   curr[i]=0;
	   for(j=0;j<2;j++)
	      {
		fscanf(fp,"%lf",&acc[i][j]);
	      }
	}
	fclose(fp);
	fp=fopen(argv[2],"r");
	trc=(double**)malloc(num_trc*sizeof(double*));
	for(i=0;i<num_trc;i++)
	{
	   trc[i]=(double*)malloc(5*sizeof(double));
	   for(j=0;j<5;j++)
	      {
		fscanf(fp,"%lf",&trc[i][j]);
	      }
	}
	fclose(fp);
	pthread_mutex_init(&assign_lock, NULL);
	pthread_mutex_init(&transact_lock,NULL);
	pthread_t tid[num_threads];
	assign_line=0;
	num_done=0;
	for(i=0;i<num_threads;i++)
	{
	   if(pthread_create(&tid[i],NULL,work,NULL))
	   {
	   	printf("Error");
		return 0;
	   }
	}
	for(i=0;i<num_threads;i++)
	{
	   pthread_join(tid[i],NULL);
	}
	for(i=0;i<10000;i++)
	{
	   printf("%d %.2lf\n",(int)acc[i][0],acc[i][1]);
	}
	free(trc);
}
