#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<sys/time.h>
#define MAX_THREADS 64
#define USAGE_EXIT(s) do{ \
                             printf("Usage: %s <# of elements> <# of threads> \n %s\n", argv[0], s); \
                            exit(-1);\
                    }while(0);
#define TDIFF(start, end) ((end.tv_sec - start.tv_sec) * 1000000UL + (end.tv_usec - start.tv_usec))
float acc[10000][2];
float** trc;
int assign_line;
int num_threads;
int num_trc;
int num_done;
int curr[10000];
pthread_mutex_t assign_lock;
pthread_mutex_t transact_lock;
void* work(void* t)
{
	int l;
	while(num_done<num_trc)
	{
		pthread_mutex_lock(&assign_lock);
		if(assign_line>=num_trc)
		{
		      pthread_mutex_unlock(&assign_lock);
		      break;
		}
		l=assign_line;
		assign_line+=1;
		if(trc[l][4]==0)
		{
		      while(curr[(int)trc[l][3]-1001]==1)
		      {
		      	   // WAIT
		      }
		      curr[(int)trc[l][3]-1001]=1;
		}
		else
		{
		      while(curr[(int)trc[l][3]-1001]==1 || curr[(int)trc[l][4]-1001]==1)
		      {
		      	   // WAIT
		      }
		      curr[(int)trc[l][3]-1001]=1;
		      curr[(int)trc[l][4]-1001]=1;
		}
		pthread_mutex_unlock(&assign_lock);
		if(trc[l][1]==1)
		{
		      acc[(int)trc[l][3]-1001][1]+=99*trc[l][2]/100;
		}
		else if(trc[l][1]==2)
		{
		      acc[(int)trc[l][3]-1001][1]-=101*trc[l][2]/100;
 		}
		else if(trc[l][1]==3)
		{
		      acc[(int)trc[l][3]-1001][1]*=107.1/100;
		}
		else
		{
		      acc[(int)trc[l][3]-1001][1]-=101*trc[l][2]/100;
		      acc[(int)trc[l][4]-1001][1]+=99*trc[l][2]/100;
 		}
		if(trc[l][4]==0)
		      curr[(int)trc[l][3]-1001]=0;
		else
		{
		      curr[(int)trc[l][3]-1001]=0;
		      curr[(int)trc[l][4]-1001]=0;
		}
		pthread_mutex_lock(&transact_lock);
		num_done+=1;
		pthread_mutex_unlock(&transact_lock);
	}
}
int main(int argc,char** argv)
{
	struct timeval start, end;
	if(argc!=5)
        	USAGE_EXIT("Not enough parameters");
	num_trc=atoi(argv[3]);
	if(num_trc < 0)
        	USAGE_EXIT("Invalid num elements");
	num_threads = atoi(argv[4]);
  	if(num_threads <=0 || num_threads > MAX_THREADS)
        	USAGE_EXIT("Invalid num of threads");
	gettimeofday(&start, NULL);
	FILE* fp;
	int i,j;
	fp=fopen(argv[1],"r");
	for(i=0;i<10000;i++)
	{
	   curr[i]=0;
	   for(j=0;j<2;j++)
	      {
		fscanf(fp,"%f",&acc[i][j]);
	      }
	}
	fclose(fp);
	fp=fopen(argv[2],"r");
	trc=(float**)malloc(num_trc*sizeof(float*));
	for(i=0;i<num_trc;i++)
	{
	   trc[i]=(float*)malloc(5*sizeof(float));
	   for(j=0;j<5;j++)
	      {
		fscanf(fp,"%f",&trc[i][j]);
	      }
	}
	fclose(fp);
	pthread_mutex_init(&assign_lock, NULL);
	pthread_mutex_init(&transact_lock,NULL);
	pthread_t tid[num_threads];
	assign_line=0;
	num_done=0;
	/*for(i=0;i<num_threads;i++)
	{
	   if(pthread_create(&tid[i],NULL,work,NULL))
	   {
	   	perror("pthread_create");
                  	exit(-1);
	   }
	}
	for(i=0;i<num_threads;i++)
	{
	   pthread_join(tid[i],NULL);
	}
	for(i=0;i<10000;i++)
	{
	   printf("%d %.2lf\n",(int)acc[i][0],acc[i][1]);
	}
	gettimeofday(&end, NULL);
	//printf("Time taken = %ld microsecs\n", TDIFF(start, end));*/
	for(i=0;i<10;i++)
	{
		printf("%d %.2f\n",(int)acc[i][0],acc[i][1]);
	}
	free(trc);
}
