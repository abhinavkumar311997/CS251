#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<sys/time.h>
#include<string.h>
#include<math.h>
#define MAX_THREADS 64
#define USAGE_EXIT(s) do{ \
                             printf("Usage: %s <# of elements> <# of threads> \n %s\n", argv[0], s); \
                            exit(-1);\
                    }while(0);
#define TDIFF(start, end) ((end.tv_sec - start.tv_sec) * 1000000UL + (end.tv_usec - start.tv_usec))
struct thread_parameters{
	pthread_t tid;
	int* array;
	int size;
	int skip;
	int max_val;
};
typedef struct thread_parameters thread;
int check(int v){
	int i;
	int flag=1;
	for(i=2;i<=sqrt(v);i++){
		if(v%i==0){
			flag=0;
			break;
		}
	}
	return flag;
}
void* prime_func(void* z){
	int  i=0;
	thread* t=(thread*)z;
	t->max_val=-1;
	while(i<t->size){
		if(check(t->array[i])){
			if(t->array[i]>t->max_val)
				t->max_val=t->array[i];
		}
		i=i+t->skip;
	}
	return NULL;
}
int main(int argc,char** argv){
	int* a;
	int max_val,num_elements,num_threads,i;
	struct timeval start, end;
	thread* arr;
	if(argc!=3)
        	USAGE_EXIT("Not enough parameters");
	num_elements=atoi(argv[1]);
	if(num_elements <=0)
        	USAGE_EXIT("Invalid num elements");
	num_threads = atoi(argv[2]);
  	if(num_threads <=0 || num_threads > MAX_THREADS)
        	USAGE_EXIT("Invalid num of threads");
	gettimeofday(&start, NULL);
	a=(int*)malloc(num_elements*sizeof(int));
	srand(1);
	for(i=0;i<num_elements;i++){
		a[i]=random();
	}
	arr=(thread*)malloc(num_threads*sizeof(thread));
	bzero(arr,num_threads*sizeof(thread));
	for(i=0;i<num_threads;i++){
		arr[i].size=num_elements-i;
		arr[i].array=a+i;
		arr[i].skip=num_threads;
		if(pthread_create(&arr[i].tid,NULL,prime_func,arr+i)!=0){
              		perror("pthread_create");
                  	exit(-1);
        	}
	}
	for(i=0;i<num_threads;i++){
		pthread_join(arr[i].tid,NULL);
		if(i==0 || i>0 && arr[i].max_val>max_val)
			max_val=arr[i].max_val;
	}
	gettimeofday(&end, NULL);
	if(max_val==-1)
		printf("No prime number among the generated array\n");
	else
		printf("Largest prime generated: %d\n",max_val);
	//printf("Time taken = %ld microsecs\n", TDIFF(start, end));
	free(a);
	free(arr);
	return 0;
}
