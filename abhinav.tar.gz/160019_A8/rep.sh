#!/bin/bash
latex report.tex
pdflatex report.tex
echo Reported > report
