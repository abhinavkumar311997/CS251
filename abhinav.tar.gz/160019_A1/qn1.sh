#!/bin/bash
word=""
read num
len=${#num}
in=0
while [ $in -lt $len ]; do
if [ ${num:$in:1} != 0 ]; then
	break                                                   # this loop checks for leading zeros
fi
let in=in+1
done
if [ $in == $len ]; then
  echo zero
else
  let len=len-in
  num=${num:$in:$len}
  in=0
  v=1
  while [ $in -lt $len ]; do
  c=${num:$in:1}
  case $c in               # after execution of this loop if the input contains anything other than digits it is reflected in the value of 'in'
  0);;
  1);;
  2);;
  3);;
  4);;
  5);;
  6);;
  7);;
  8);;
  9);;
  *)v=0 
    break;;
  esac
  let in=in+1
  done
  if [ $in -lt $len ]; then
  	echo invalid input
  else
  	in=0
  	base () {
  	if [ $2 == 1 ]; then
  	case $1 in
  	1)word="$word one";;
  	2)word="$word two";;
  	3)word="$word three";;
  	4)word="$word four";;
  	5)word="$word five";;
  	6)word="$word six";;
  	7)word="$word seven";;
  	8)word="$word eight";;
  	9)word="$word nine";;
  	esac
  	else
  		if [ ${1:0:1} == 1 ]; then
  			case ${1:1:1} in
  			0)word="$word ten";;
  			1)word="$word eleven";;
  			2)word="$word tweleve";;
  			3)word="$word thirteen";;
  			4)word="$word fourteen";;
  			5)word="$word fifteen";;
  			6)word="$word sixteen";;
  			7)word="$word seventeen";;
  			8)word="$word eighteen";;
  			9)word="$word nineteen";;
  			esac
  		else
  			tens ${1:0:1}
  			case ${1:1:1} in
  			1)word="$word  one";;
  			2)word="$word  two";;
  			3)word="$word  three";;
  			4)word="$word  four";;
  			5)word="$word  five";;
  			6)word="$word  six";;
  			7)word="$word  seven";;
  			8)word="$word  eight";;
  			9)word="$word  nine";;
  			esac
  		fi
  	fi
  	}
  	tens () {
  	case $1 in
  	2)word="$word twenty";;
  	3)word="$word thirty";;
  	4)word="$word fourty";;
  	5)word="$word fifty";;
  	6)word="$word sixty";;
  	7)word="$word seventy";;
  	8)word="$word eighty";;
  	9)word="$word ninety";;
  	esac
  	}
  	hundreds () {
	base $1 1
	if [ $1 != 0 ]; then
        	word="$word hundred"
        fi
	}
	thousands () {
	if [ $2 == 1 ]; then
		base $1 1
                if [ $1 != 0 ]; then
			word="$word thousand"
		fi
	else
		base $1 2
		if [ ${1:0:1} != 0 ] || [ ${1:1:1} != 0 ]; then
			word="$word thousand"
		fi
	fi
	}
	lakhs () {
	if [ $2 == 1 ]; then
		base $1 1
                if [ $1 != 0 ]; then
			word="$word lakh"
                fi
	else
		base $1 2
                if [ ${1:1:1} != 0 ] || [ ${1:0:1} != 0 ]; then
			word="$word lakh"
		fi
	fi
	}
	crores () {
	if [ $2 == 1 ]; then
		base $1 1
		word="$word crore"
	elif [ $2 == 2 ]; then
		base $1 2
		word="$word crore"
	elif [ $2 == 3 ]; then
		hundreds ${1:0:1}
		base ${1:1:2} 2
		word="$word crore"
	else
		thousands ${1:0:1} 1
		hundreds ${1:1:1} 
		base ${1:2:2} 2
		word="$word crore"
	fi
	}
	if [ $len == 1 ]; then
		base $num 1
	elif [ $len == 2 ]; then
		base $num 2
	elif [ $len == 3 ]; then
		hundreds ${num:0:1}
		base ${num:1:2} 2
	elif [ $len == 4 ]; then
		thousands ${num:0:1} 1
		hundreds ${num:1:1}
		base ${num:2:2} 2
	elif [ $len == 5 ]; then
		thousands ${num:0:2} 2
		hundreds ${num:2:1}
		base ${num:3:2} 2
	elif [ $len == 6 ]; then
		lakhs ${num:0:1} 1
		thousands ${num:1:2} 2
		hundreds ${num:3:1}
		base ${num:4:2} 2
	elif [ $len == 7 ]; then
		lakhs ${num:0:2} 2
		thousands ${num:2:2} 2
		hundreds ${num:4:1}
		base ${num:5:2} 2
	elif [ $len == 8 ]; then
		crores ${num:0:1} 1
		lakhs ${num:1:2} 2
		thousands ${num:3:2} 2
		hundreds ${num:5:1}
		base ${num:6:2} 2
	elif [ $len == 9 ]; then
		crores ${num:0:2} 2
		lakhs ${num:2:2} 2
		thousands ${num:4:2} 2
		hundreds ${num:6:1}
		base ${num:7:2} 2
	elif [ $len == 10 ]; then
		crores ${num:0:3} 3
		lakhs ${num:3:2} 2
		thousands ${num:5:2} 2
		hundreds ${num:7:1}
		base ${num:8:2} 2
	elif [ $len == 11 ]; then
		crores ${num:0:4} 4
		lakhs ${num:4:2} 2
		thousands ${num:6:2} 2
		hundreds ${num:8:1}
		base ${num:9:2} 2
	fi
	echo $word
  fi 
fi
