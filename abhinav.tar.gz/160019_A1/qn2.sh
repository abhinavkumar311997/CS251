#!/bin/bash
tab="       "
rs=0
ri=0
info () {							# receives the file content and length returns sentences and integers count
	local in=0
	ns=0
	ni=0
	while [ $in -lt $2 ]; do
		if [ "${1:in:1}" = "?" ]; then
			let ns=ns+1
		elif [ "${1:in:1}" = "!" ]; then
			let ns=ns+1
		elif [ "${1:in:1}" = "." ]; then
			if [ $in == $(($2-1)) ]; then
 				let ns=ns+1
			elif [ $in == 0 ]; then
				let ns=ns+1
			elif [[ "${1:$(($in-1)):1}" = *[0-9]* ]] && [[ "${1:$(($in+1)):1}" = *[0-9]* ]]; then
				let ns=ns+0
			else
				let ns=ns+1
			fi
		fi
	let in=in+1		
	done
	in=0
	while [ $in -lt $2 ]; do
		if [[ "${1:in:1}" = *[0-9]* ]]; then
			let in=in+1
			while [ $in -lt $2 ]; do
				if [[ "${1:in:1}" = *[0-9]* ]]; then
					let in=in+1
				else
					break
				fi
			done
			if [ $in == $(($2-1)) ]; then
				let ni=ni+1
			elif [ "${1:in:1}" = "." ]; then
				let in=in+1
				if [[ "${1:in:1}" = *[0-9]* ]]; then
					let in=in+1
					while [[ "${1:in:1}" = *[0-9]* ]]; do
						let in=in+1
						if [ $in == $2 ]; then
							break
						fi
						if [ "${1:in:1}" = "." ]; then
							let in=in+1
						fi
					done
				else
					let ni=ni+1
				fi
			else
				let ni=ni+1
			fi
		else
			let in=in+1	
		fi
	done
}
travel () {
	local num1=0
	local num2=0
	if [ -f "$1" ]; then
		str=$(cat $1)
		str=$(echo $str | tr "\n" " ")                         # replace the newline character in files with spaces
		info "$str" $((${#str}-1))                             # if the path is file send it to info to get sentences and integers count
		counter=0;
		while [ $counter -lt $2 ]; do
			echo -n "$tab"
			let counter=counter+1
		done
		echo "(F)" $(basename $1)-$ns-$ni
		rs=$ns
		ri=$ni
	else
		for i in $(ls $1); do
			travel $1/$i $(($2+1))
			let num1=num1+$rs
			let num2=num2+$ri
		done
		counter=0
		while [ $counter -lt $2 ]; do                         # if directory then call for inner files and directories
			echo -n "$tab"
			let counter=counter+1
		done
		echo "(D)" $(basename $1)-$num1-$num2
		rs=$num1
		ri=$num2
	fi	
}
read path
depth=0
travel $path $depth                 # depth records the number of times tab to be printed at each node of tree
